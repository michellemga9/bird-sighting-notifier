# 🐦 Rare Bird Sighting Alerts

Automatiskt notissystem som övervakar eBird för sällsynta och noterbara fågelobservationer nära din plats!

## 🎯 Funktioner

- ✅ Övervakar eBird API för sällsynta fågelobservationer
- ✅ Konfigurerbartradius (standard: 25km)
- ✅ Email-notiser med detaljerad info
- ✅ Google Maps-länkar till observationsplatsen
- ✅ Direktlänkar till eBird för mer info
- ✅ Körs automatiskt var 6:e timme via GitHub Actions
- ✅ Fungerar för hela världen!

## 🐦 Vad är "Notable" fåglar?

eBird markerar automatiskt observationer som "notable" om:
- Arten är ovanlig för platsen eller tidpunkten
- Arten är sällsynt generellt
- Observationen är ovanlig (t.ex. mycket tidigt/sent på säsongen)
- Fågeln är långt från sitt normala område

## 🚀 Snabbstart

### Steg 1: Skaffa eBird API Key (GRATIS!)

1. Gå till: https://ebird.org/api/keygen
2. Logga in eller skapa ett eBird-konto (gratis)
3. Fyll i formuläret
4. Du får din API-nyckel direkt!

### Steg 2: Skapa GitHub Repository

1. Gå till: https://github.com/new
2. Repository name: `bird-notifier`
3. Public eller Private (din preferens)
4. Klicka "Create repository"

### Steg 3: Ladda upp filerna

1. Ladda upp dessa filer till ditt repo:
   - `bird_notifier.py`
   - `.github/workflows/bird-notifier.yml`
   - `requirements.txt`
   - `README.md`

### Steg 4: Konfigurera GitHub Secrets

Gå till: **Settings → Secrets and variables → Actions → New repository secret**

#### Obligatoriska Secrets:

**EBIRD_API_KEY**
- Value: `din-ebird-api-nyckel-här`
- Din API-nyckel från steg 1

**SENDER_EMAIL**
- Value: `din.email@gmail.com`
- Gmail-adress för att skicka notiser

**SENDER_PASSWORD**
- Value: `xxxx xxxx xxxx xxxx`
- Gmail App Password (se instruktioner nedan)

**RECEIVER_EMAIL**
- Value: `mottagare@email.com`
- Vart notiser ska skickas (kan vara samma som SENDER_EMAIL)

**SMTP_SERVER**
- Value: `smtp.gmail.com`

**SMTP_PORT**
- Value: `587`

#### Valfria Secrets (för anpassning):

**LATITUDE**
- Value: `59.6167` (ditt lat)
- Din position (standard: Märsta)

**LONGITUDE**
- Value: `17.8667` (ditt long)
- Din position (standard: Märsta)

**RADIUS_KM**
- Value: `25`
- Sökradie i kilometer (standard: 25km)

**DAYS_BACK**
- Value: `3`
- Hur många dagar tillbaka att kolla (standard: 3)

### Steg 5: Gmail App Password

1. Gå till: https://myaccount.google.com/security
2. Aktivera "2-Step Verification"
3. Gå till: https://myaccount.google.com/apppasswords
4. Skapa password för "Mail"
5. Kopiera det 16-siffriga lösenordet
6. Använd som `SENDER_PASSWORD`

### Steg 6: Testa!

1. Gå till **Actions** i ditt repo
2. Klicka på **"Rare Bird Sighting Alerts"**
3. Klicka **"Run workflow"**
4. Vänta 30 sekunder
5. Kolla din email! 📧

## 📧 Email-exempel

När sällsynta fåglar hittas får du ett email som:

```
🐦 3 Rare Bird Sightings Alert!

Eurasian Hoopoe
Upupa epops
📍 Location: Djurgården, Stockholm
🕐 When: 2026-02-15 08:30
🔢 Count: 1 individual
[View on Map] [View on eBird]

...
```

## ⚙️ Anpassning

### Ändra sökradie

Standard är 25km. För att ändra:
1. Gå till Secrets
2. Lägg till `RADIUS_KM`
3. Value: `50` (eller önskad radie)

### Ändra kontrollfrekvens

Redigera `.github/workflows/bird-notifier.yml`:

```yaml
schedule:
  - cron: '0 */3 * * *'  # Var 3:e timme
  - cron: '0 8,16 * * *'  # Kl 8 och 16
  - cron: '0 6 * * *'     # Varje dag kl 6
```

### Andra länder/platser

Systemet fungerar GLOBALT! Ändra bara LATITUDE och LONGITUDE:

**Göteborg:** 57.7089, 11.9746
**London:** 51.5074, -0.1278
**New York:** 40.7128, -74.0060
**Tokyo:** 35.6762, 139.6503

## 🌍 Global användning

eBird har data från hela världen! Använd detta för:
- **Sverige**: Sällsynta nordiska arter
- **UK**: Rare British birds
- **USA**: ABA rarities
- **Japan**: Asian vagrants
- **Australia**: Endemics

## 🔍 Hitta din plats

1. Gå till: https://www.latlong.net/
2. Sök din stad/plats
3. Kopiera Latitude och Longitude
4. Lägg till som secrets!

## 📊 Vad händer nu?

Systemet kommer automatiskt:
- ✅ Kolla eBird var 6:e timme
- ✅ Hitta alla "notable" observationer inom din radie
- ✅ Skicka email när nya sällsynta fåglar hittas
- ✅ Inkludera karta och eBird-länkar

## 🐦 Populära områden i Sverige

**Falsterbo** (migration hotspot):
- Latitude: 55.3833
- Longitude: 12.8167
- Radius: 10km

**Öland** (rarities):
- Latitude: 56.6634
- Longitude: 16.4942
- Radius: 20km

**Hornborgasjön** (cranes):
- Latitude: 58.3167
- Longitude: 13.5500
- Radius: 15km

## 🎓 För nybörjare

**Vad är eBird?**
- Världens största databas för fågelobservationer
- Miljontals observationer dagligen
- Använt av forskare, fågelskådare, naturvårdare

**Vad är "Notable"?**
- eBird's algoritm markerar ovanliga observationer
- Baserat på plats, tid, art, frekvens
- Perfekt för att hitta sällsynta fåglar!

## 🔧 Felsökning

### Får inga emails
- Kontrollera Gmail App Password
- Verifiera alla secrets är korrekta
- Kolla workflow logs för errors

### För många emails
- Öka DAYS_BACK (färre observationer)
- Minska RADIUS_KM (mindre område)
- Ändra schedule (mindre frekvent)

### Inga fåglar hittas
- Öka RADIUS_KM (större område)
- Öka DAYS_BACK (längre tidsperiod)
- Flytta till populärt fågelområde

## 📚 Resurser

- **eBird**: https://ebird.org
- **eBird API Docs**: https://documenter.getpostman.com/view/664302/S1ENwy59
- **Fågelguider**: https://www.fageldragning.nu/
- **Artportalen**: https://www.artportalen.se/

## 🤝 Community

- **r/birding**: Reddit community
- **Cloudbirders**: Rare bird alerts mailing list
- **Tåkern Bird Station**: Swedish birding
- **BirdLife Sverige**: Conservation organization

## 🌟 Upgrades (Framtida idéer)

- [ ] SMS-notiser (Twilio)
- [ ] Slack-integration
- [ ] Filter på specifika arter
- [ ] Rarity score system
- [ ] Automatisk checklist-länk
- [ ] Väderprogn os för observation
- [ ] Foton från eBird

## 📄 Licens

MIT License - använd fritt!

## ❤️ Tack till

- **eBird/Cornell Lab of Ornithology** för fantastisk API
- **Alla fågelskådare** som rapporterar observationer
- **BirdLife International** för naturvård

---

**Lycka till med fågelskådningen! 🐦✨**

*Din personliga sällsynta fågel-scout, 24/7!*
